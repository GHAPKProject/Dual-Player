package com.example.dualplayer;

import android.Manifest;
import android.app.*;
import android.app.PictureInPictureParams;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK_MEDIA=10, PICK_ICON=11;
    LinearLayout root, content, nav; TextView title; MediaPlayer player; VideoView video; ImageView image;
    WebView web; Uri currentUri; DB db; SharedPreferences prefs; boolean playing=false; long currentMediaId=-1;
    int blue=Color.rgb(22,168,255), green=Color.rgb(54,232,138), bg=Color.rgb(11,18,32), surface=Color.rgb(18,27,45), white=Color.rgb(244,247,251), muted=Color.rgb(154,168,186);

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); db=new DB(this); prefs=getSharedPreferences("settings",0); buildShell(); showHome(); requestMediaPermissions();}
    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this); bar.setPadding(28,20,20,14); bar.setGravity(Gravity.CENTER_VERTICAL);
        title=txt("O'U Dual Player",22,white); bar.addView(title,new LinearLayout.LayoutParams(0,60,1));
        TextView search=button("⌕"); search.setOnClickListener(v->showLibrary(true)); bar.addView(search,new LinearLayout.LayoutParams(60,60)); root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,8,18,8); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(6,6,6,8); nav.setBackgroundColor(surface);
        addNav("⌂\nHome",v->showHome()); addNav("▣\nLibrary",v->showLibrary(false)); addNav("◉\nOnline",v->showBrowser()); addNav("☷\nPlaylists",v->showPlaylists()); addNav("⚙\nSettings",v->showSettings()); root.addView(nav,new LinearLayout.LayoutParams(-1,76)); setContentView(root);
    }
    void addNav(String s,View.OnClickListener l){TextView t=txt(s,12,white);t.setGravity(Gravity.CENTER);t.setOnClickListener(l);nav.addView(t,new LinearLayout.LayoutParams(0,68,1));}
    TextView txt(String s,float sp,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(c);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    TextView button(String s){TextView t=txt(s,15,white);t.setGravity(Gravity.CENTER);t.setBackground(round(surface));return t;}
    GradientDrawable round(int c){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(22);return g;}
    void clear(){content.removeAllViews();}
    TextView heading(String s){TextView t=txt(s,24,white);t.setPadding(4,10,4,14);return t;}
    Button action(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setOnClickListener(l);return b;}
    void showHome(){clear(); content.addView(heading("Your media, one place"));
        TextView sub=txt("Local player + online browser + playlists + history",15,muted);content.addView(sub);
        LinearLayout cards=new LinearLayout(this);cards.setOrientation(LinearLayout.VERTICAL);cards.setPadding(0,16,0,8);
        cards.addView(action("▶  Open Video / Photo",v->pickMedia()),new LinearLayout.LayoutParams(-1,56));
        cards.addView(action("▣  Browse Local Library",v->showLibrary(false)),new LinearLayout.LayoutParams(-1,56));
        cards.addView(action("◎  Open Online URL",v->showBrowser()),new LinearLayout.LayoutParams(-1,56));
        content.addView(cards); content.addView(heading("Continue Watching")); addHistoryRows(4); content.addView(heading("Favorites")); addFavoriteRows(3);
    }
    void pickMedia(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_MEDIA);}
    void requestMediaPermissions(){if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO,Manifest.permission.READ_MEDIA_IMAGES},77);else if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},77);}
    void showLibrary(boolean focus){clear();content.addView(heading("Media Library"));
        LinearLayout tools=new LinearLayout(this);tools.addView(action("＋ Add",v->pickMedia()),new LinearLayout.LayoutParams(0,52,1));tools.addView(action("↕ Sort",v->showLibrary(false)),new LinearLayout.LayoutParams(0,52,1));content.addView(tools);
        Cursor c=getContentResolver().query(MediaStore.Files.getContentUri("external"),new String[]{MediaStore.Files.FileColumns._ID,MediaStore.Files.FileColumns.MEDIA_TYPE,MediaStore.Files.FileColumns.DISPLAY_NAME,MediaStore.Files.FileColumns.SIZE},MediaStore.Files.FileColumns.MEDIA_TYPE+"=? OR "+MediaStore.Files.FileColumns.MEDIA_TYPE+"=?",new String[]{"3","1"},MediaStore.Files.FileColumns.DATE_ADDED+" DESC");
        if(c!=null){while(c.moveToNext()){long id=c.getLong(0);int type=c.getInt(1);String name=c.getString(2);long size=c.getLong(3);Uri u=Uri.withAppendedPath(MediaStore.Files.getContentUri("external"),String.valueOf(id)); addMediaRow(name,size,u,type==3);}c.close();}
        if(content.getChildCount()<=2)content.addView(txt("No media found. Tap Add to choose files.",15,muted));
    }
    void addMediaRow(String name,long size,Uri u,boolean videoType){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(8,6,4,6);TextView n=txt((videoType?"▶  ":"▧  ")+name+"\n"+human(size),15,white);row.addView(n,new LinearLayout.LayoutParams(0,64,1));TextView play=button("Open");play.setOnClickListener(v->openMedia(u,videoType,name));row.addView(play,new LinearLayout.LayoutParams(80,54));row.setOnLongClickListener(v->{popupMedia(name,u);return true;});content.addView(row);}
    String human(long n){if(n<1024)return n+" B";if(n<1048576)return n/1024+" KB";if(n<1073741824)return n/1048576+" MB";return n/1073741824+" GB";}
    void popupMedia(String name,Uri u){new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"Play / View","Add to Favorites","Add to Playlist","Share","Delete"},(d,w)->{if(w==0)openMedia(u,true,name);if(w==1)db.favorite(name,u.toString());if(w==2)choosePlaylist(name,u);if(w==3){Intent s=new Intent(Intent.ACTION_SEND);s.setType("*/*");s.putExtra(Intent.EXTRA_STREAM,u);startActivity(Intent.createChooser(s,"Share"));}if(w==4)Toast.makeText(this,"Use the system Files app to delete protected MediaStore items.",Toast.LENGTH_LONG).show();}).show();}
    void openMedia(Uri u,boolean videoType,String name){currentUri=u;db.history(name,u.toString());clear();content.addView(heading(name));
        if(videoType){video=new VideoView(this);video.setVideoURI(u);video.setMediaController(new MediaController(this));video.setOnPreparedListener(mp->{player=mp;player.setLooping(prefs.getBoolean("loop",false));long pos=db.position(u.toString());if(pos>0)player.seekTo((int)pos);player.start();playing=true;});video.setOnCompletionListener(v->db.position(u.toString(),0));content.addView(video,new LinearLayout.LayoutParams(-1,0,1));
            LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);controls.addView(action("0.5×",v->speed(.5f)));controls.addView(action("1×",v->speed(1f)));controls.addView(action("1.5×",v->speed(1.5f)));controls.addView(action("2×",v->speed(2f)));controls.addView(action("▣ PiP",v->pip()));content.addView(controls,new LinearLayout.LayoutParams(-1,60));
        }else{image=new ImageView(this);image.setImageURI(u);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setOnTouchListener(new ZoomTouch(image));content.addView(image,new LinearLayout.LayoutParams(-1,0,1));content.addView(action("Share",v->{Intent s=new Intent(Intent.ACTION_SEND);s.setType("image/*");s.putExtra(Intent.EXTRA_STREAM,u);startActivity(Intent.createChooser(s,"Share image"));}));}
    }
    void speed(float x){if(player!=null&&Build.VERSION.SDK_INT>=23){player.setPlaybackParams(player.getPlaybackParams().setSpeed(x));Toast.makeText(this,x+"×",Toast.LENGTH_SHORT).show();}}
    void pip(){if(Build.VERSION.SDK_INT>=26){try{enterPictureInPictureMode(new PictureInPictureParams.Builder().build());}catch(Exception e){Toast.makeText(this,"Picture-in-picture unavailable",Toast.LENGTH_SHORT).show();}}}
    void showBrowser(){clear();content.addView(heading("Online Player"));LinearLayout urlrow=new LinearLayout(this);EditText url=new EditText(this);url.setSingleLine();url.setHint("https://example.com/video");url.setText(prefs.getString("homeUrl","https://www.youtube.com"));urlrow.addView(url,new LinearLayout.LayoutParams(0,54,1));urlrow.addView(action("Go",v->loadUrl(url.getText().toString())),new LinearLayout.LayoutParams(70,54));content.addView(urlrow);
        web=new WebView(this);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());content.addView(web,new LinearLayout.LayoutParams(-1,0,1));loadUrl(url.getText().toString());}
    void loadUrl(String x){if(x==null||x.trim().isEmpty())return;String u=x.trim();if(!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))u="https://www.google.com/search?q="+Uri.encode(u);prefs.edit().putString("homeUrl",u).apply();if(web!=null)web.loadUrl(u);}
    void showPlaylists(){clear();content.addView(heading("Playlists"));content.addView(action("＋ New Playlist",v->newPlaylist()));Cursor c=db.playlists();while(c.moveToNext()){String n=c.getString(1);int count=c.getInt(2);TextView r=button(n+"  ·  "+count+" items");r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(18,0,8,0);r.setOnClickListener(v->showPlaylist(c.getLong(0),n));content.addView(r,new LinearLayout.LayoutParams(-1,58));}c.close();}
    void newPlaylist(){final EditText e=new EditText(this);e.setHint("Playlist name");new AlertDialog.Builder(this).setTitle("Create playlist").setView(e).setPositiveButton("Create",(d,w)->{if(e.getText().length()>0){db.createPlaylist(e.getText().toString());showPlaylists();}}).setNegativeButton("Cancel",null).show();}
    void showPlaylist(long id,String name){clear();content.addView(heading(name));Cursor c=db.items(id);while(c.moveToNext()){String n=c.getString(1);Uri u=Uri.parse(c.getString(2));TextView r=button("▶  "+n);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(18,0,8,0);r.setOnClickListener(v->openMedia(u,true,n));content.addView(r,new LinearLayout.LayoutParams(-1,58));}c.close();content.addView(action("Delete playlist",v->{db.deletePlaylist(id);showPlaylists();}));}
    void choosePlaylist(String name,Uri u){Cursor c=db.playlists();ArrayList<Long> ids=new ArrayList<>();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));}c.close();if(names.isEmpty()){newPlaylist();return;}new AlertDialog.Builder(this).setTitle("Add to playlist").setItems(names.toArray(new String[0]),(d,w)->db.addItem(ids.get(w),name,u.toString())).show();}
    void showSettings(){clear();content.addView(heading("Settings"));
        TextView app=txt("O'U Dual Player\nFull local + online media suite",16,white);app.setPadding(12,8,12,18);content.addView(app);
        Switch loop=new Switch(this);loop.setText("Loop videos");loop.setTextColor(white);loop.setChecked(prefs.getBoolean("loop",false));loop.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("loop",v).apply());content.addView(loop);
        content.addView(action("🖼 Choose image for custom home-screen icon",v->pickIcon()));
        content.addView(action("★ View Favorites",v->showFavorites()));content.addView(action("◷ Playback History",v->showHistory()));content.addView(action("⌫ Clear History",v->{db.clearHistory();Toast.makeText(this,"History cleared",Toast.LENGTH_SHORT).show();}));
        content.addView(action("Browser: clear data",v->{if(web!=null){web.clearHistory();web.clearCache(true);}Toast.makeText(this,"Browser data cleared",Toast.LENGTH_SHORT).show();}));
        content.addView(txt("\nCustom icon note: Android does not let an ordinary app replace its installed package icon with an arbitrary runtime bitmap. This option creates a pinned home-screen shortcut using your chosen image when the launcher supports it.",13,muted));
    }
    void pickIcon(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_ICON);}
    void createCustomShortcut(Uri u){if(Build.VERSION.SDK_INT<26){Toast.makeText(this,"Custom launcher shortcuts require Android 8+.",Toast.LENGTH_LONG).show();return;}try{Bitmap bm=BitmapFactory.decodeStream(getContentResolver().openInputStream(u));if(bm==null)throw new Exception();ShortcutManager sm=getSystemService(ShortcutManager.class);if(sm==null||!sm.isRequestPinShortcutSupported()){Toast.makeText(this,"Your launcher does not support pinned shortcuts.",Toast.LENGTH_LONG).show();return;}ShortcutInfo info=new ShortcutInfo.Builder(this,"ou_custom_player").setShortLabel("O'U Player").setLongLabel("O'U Dual Player").setIcon(android.graphics.drawable.Icon.createWithBitmap(bm)).setIntent(new Intent(this,MainActivity.class).setAction(Intent.ACTION_MAIN)).build();sm.requestPinShortcut(info,null);Toast.makeText(this,"Shortcut request sent to launcher.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Could not create icon: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    void addHistoryRows(int max){Cursor c=db.history();int n=0;while(c.moveToNext()&&n++<max){String name=c.getString(1);Uri u=Uri.parse(c.getString(2));TextView r=button("▶ "+name);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(14,0,8,0);r.setOnClickListener(v->openMedia(u,true,name));content.addView(r,new LinearLayout.LayoutParams(-1,54));}c.close();if(n==0)content.addView(txt("Nothing played yet.",14,muted));}
    void addFavoriteRows(int max){Cursor c=db.favorites();int n=0;while(c.moveToNext()&&n++<max){String name=c.getString(1);Uri u=Uri.parse(c.getString(2));TextView r=button("★ "+name);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(14,0,8,0);r.setOnClickListener(v->openMedia(u,true,name));content.addView(r,new LinearLayout.LayoutParams(-1,54));}c.close();if(n==0)content.addView(txt("No favorites yet.",14,muted));}
    void showHistory(){clear();content.addView(heading("History"));addHistoryRows(100);}
    void showFavorites(){clear();content.addView(heading("Favorites"));addFavoriteRows(100);}
    @Override protected void onPause(){super.onPause();if(currentUri!=null&&player!=null)db.position(currentUri.toString(),player.getCurrentPosition());}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;if(r==PICK_ICON&&d.getData()!=null){createCustomShortcut(d.getData());return;}if(r==PICK_MEDIA){ClipData cd=d.getClipData();if(cd!=null){for(int i=0;i<cd.getItemCount();i++)db.history("Imported media",cd.getItemAt(i).getUri().toString());}else if(d.getData()!=null)openPicked(d.getData());}}
    void openPicked(Uri u){String type=getContentResolver().getType(u);boolean v=type!=null&&type.startsWith("video/");openMedia(u,v,"Selected media");}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack()){web.goBack();return;}super.onBackPressed();}

    static class ZoomTouch implements View.OnTouchListener{ImageView v;float scale=1,dx,dy,lastX,lastY;ScaleGestureDetector detector;ZoomTouch(ImageView x){v=x;detector=new ScaleGestureDetector(x.getContext(),new ScaleGestureDetector.SimpleOnScaleGestureListener(){public boolean onScale(ScaleGestureDetector d){scale=Math.max(1,Math.min(5,scale*d.getScaleFactor()));v.setScaleX(scale);v.setScaleY(scale);return true;}});}public boolean onTouch(View x,android.view.MotionEvent e){detector.onTouchEvent(e);return true;}}

    static class DB extends android.database.sqlite.SQLiteOpenHelper{
        DB(Context c){super(c,"ouplayer.db",null,2);}public void onCreate(android.database.sqlite.SQLiteDatabase d){d.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY,name TEXT,url TEXT,position INTEGER DEFAULT 0,ts INTEGER)");d.execSQL("CREATE TABLE fav(id INTEGER PRIMARY KEY,name TEXT,url TEXT)");d.execSQL("CREATE TABLE playlists(id INTEGER PRIMARY KEY,name TEXT)");d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY,playlist INTEGER,name TEXT,url TEXT)");}public void onUpgrade(android.database.sqlite.SQLiteDatabase d,int a,int b){d.execSQL("DROP TABLE IF EXISTS items");d.execSQL("DROP TABLE IF EXISTS playlists");d.execSQL("DROP TABLE IF EXISTS fav");d.execSQL("DROP TABLE IF EXISTS history");onCreate(d);}
        void history(String n,String u){android.database.sqlite.SQLiteDatabase d=getWritableDatabase();d.delete("history","url=?",new String[]{u});d.execSQL("INSERT INTO history(name,url,ts) VALUES(?,?,?)",new Object[]{n,u,System.currentTimeMillis()});}
        void position(String u,long p){getWritableDatabase().execSQL("UPDATE history SET position=?,ts=? WHERE url=?",new Object[]{p,System.currentTimeMillis(),u});}long position(String u){Cursor c=getReadableDatabase().rawQuery("SELECT position FROM history WHERE url=?",new String[]{u});long p=0;if(c.moveToFirst())p=c.getLong(0);c.close();return p;}
        void favorite(String n,String u){getWritableDatabase().execSQL("INSERT OR REPLACE INTO fav(name,url) VALUES(?,?)",new Object[]{n,u});}
        Cursor history(){return getReadableDatabase().query("history",null,null,null,null,null,"ts DESC");}Cursor favorites(){return getReadableDatabase().query("fav",null,null,null,null,null,"id DESC");}void clearHistory(){getWritableDatabase().delete("history",null,null);}
        void createPlaylist(String n){getWritableDatabase().execSQL("INSERT INTO playlists(name) VALUES(?)",new Object[]{n});}Cursor playlists(){return getReadableDatabase().rawQuery("SELECT p.id,p.name,(SELECT count(*) FROM items i WHERE i.playlist=p.id) FROM playlists p ORDER BY p.id DESC",null);}Cursor items(long id){return getReadableDatabase().query("items",null,"playlist=?",new String[]{String.valueOf(id)},null,null,"id DESC");}void addItem(long p,String n,String u){getWritableDatabase().execSQL("INSERT INTO items(playlist,name,url) VALUES(?,?,?)",new Object[]{p,n,u});}void deletePlaylist(long p){getWritableDatabase().delete("items","playlist=?",new String[]{String.valueOf(p)});getWritableDatabase().delete("playlists","id=?",new String[]{String.valueOf(p)});}
    }
}
