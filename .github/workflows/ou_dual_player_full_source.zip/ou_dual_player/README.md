# O'U Dual Player — full-version rebuild

This project keeps the original package/application ID `com.example.dualplayer` and raises the version to `2.0.0` (`versionCode 2`) so it is prepared as an update **only if it is signed with the same signing key as the installed app**.

## Important update/signing limitation

The supplied `base.apk` is signed with an Android Debug certificate. The private key is not contained in an APK, so it cannot be recovered from `base.apk`. Android requires the new APK to have the same application ID **and the same signing certificate** to install it as an update.

Therefore:

- Do not uninstall the existing app if preserving its data is important until the signing key is confirmed.
- If you have the original `.jks`/`.keystore` used to build the installed `Dual Player`, put it into a secure location and configure Gradle signing with that key.
- If the original private key is unavailable, Android will require the old app to be uninstalled before installing this rebuild. That is an Android security rule, not an application setting.
- Once a new key is chosen for O'U Dual Player, keep it permanently for all future updates.

## Included full-version direction

- O'U Dual Player branding and generated launcher icon
- Local video/photo picker
- MediaStore local library
- Video playback with Android MediaController
- Playback speed controls
- Loop setting
- Resume position/history
- Favorites
- Playlists
- Online WebView player/browser
- Browser history/cache clearing
- Picture-in-picture
- Image viewing with zoom
- Sharing
- Settings
- Custom image -> pinned home-screen shortcut icon on Android 8+ launchers that support pinned shortcuts

## Custom app icon behavior

Android does not allow a normal installed application to replace its own package launcher icon with an arbitrary runtime bitmap. The Settings option therefore creates a **pinned home-screen shortcut** using the selected image. The shortcut launches O'U Dual Player and can visually act as the custom icon on supported launchers.

## Build

Open the project in Android Studio and let Gradle install the required Android SDK/Build Tools. The project uses `compileSdk 35`, `minSdk 26`, and `targetSdk 35`.

For a release build, configure the original signing key if you have it. Without that key, the generated APK cannot update the currently installed APK even though the application ID is identical.
